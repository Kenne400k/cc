exports.error = (next, message, status = 500) => {
    const error = new Error(message);
    error.status = status;
    next(error);
  };
  exports.log = (data, type) => {
    const log = console.log("[37m-> [32m" + type.toUpperCase() + "[37m <-[0m", data);
    next(log);
  };
  